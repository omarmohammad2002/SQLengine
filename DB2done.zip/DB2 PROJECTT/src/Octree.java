import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Vector;

public class Octree<T> implements Serializable {
	private Bucket Bucket; 
	private Octree<T>[] children = new Octree[8];
	private T object;
	private String col1 ;
	private String col2 ;
	private String col3 ;
	
	public Octree(Object x1,Object y1, Object z1, Object x2,Object y2,Object z2, String str1, String str2, String  str3) throws DBAppException{
		Bucket = new Bucket ( x1, y1,  z1,  x2, y2, z2) ; 
		this.col1= str1 ;
		this.col2= str2 ;
		this.col3= str3 ;
	}
	public void insert(Object x, Object y, Object z, String s, Object clusteringKey) throws Exception {
		if(find(x, y, z)){
			insertintoduplicates(x,y,z,s,clusteringKey) ; 
			return ;
		}

		if ( ((((Comparable)x).compareTo((Comparable)Bucket.getMinx())) < 0) || ((((Comparable)x).compareTo((Comparable)Bucket.getMaxx())) > 0)
				||  ((((Comparable)y).compareTo((Comparable)Bucket.getMiny())) < 0)||  ((((Comparable)y).compareTo((Comparable)Bucket.getMaxy())) > 0)
				||  ((((Comparable)z).compareTo((Comparable)Bucket.getMinz())) < 0) ||  ((((Comparable)z).compareTo((Comparable)Bucket.getMaxz())) > 0))
			throw new OutOfBoundsException("Insertion point is out of bounds! ") ;
		Object midx = getMidObject(Bucket.getMaxx(),Bucket.getMinx()) ;
		Object midy = getMidObject(Bucket.getMaxy(),Bucket.getMiny()) ;
		Object midz = getMidObject(Bucket.getMaxz(),Bucket.getMinz()) ; 
		
		if (this.children[0] == null) {
			if (Bucket.getCount()<Bucket.getSize())
			{ 
				Bucket.getBucket().add(s) ;
				Bucket.getClusteringkeys().add(clusteringKey) ; 
				this.Bucket.setCount(this.Bucket.getCount()+1);
				OctPoint t = new OctPoint (x,y,z) ; 
				Vector <OctPoint> v = this.Bucket.getLocations() ; 
				v.add(t) ;
				this.Bucket.setLocations(v) ; 
			}
			else {
				children[0] = new Octree((midx), (midy), (midz), this.Bucket.getMaxx(),this.Bucket.getMaxy(),this.Bucket.getMaxz(),this.col1,this.col2,this.col3);
				children[1] = new Octree((midx), (midy), Bucket.getMinz(), this.Bucket.getMaxx(),this.Bucket.getMaxy(),midz,this.col1,this.col2,this.col3);
				children[2] = new Octree((midx),Bucket.getMiny(),(midz),this.Bucket.getMaxx(),midy,this.Bucket.getMaxz(),this.col1,this.col2,this.col3);
				children[3] = new Octree((midx),Bucket.getMiny(),Bucket.getMinz(),this.Bucket.getMaxx(),midy,midz,this.col1,this.col2,this.col3);
				children[4] = new Octree(Bucket.getMinx(),(midy),(midz),midx, Bucket.getMaxy(),Bucket.getMaxz(),this.col1,this.col2,this.col3);
				children[5] = new Octree(Bucket.getMinx(),(midy),Bucket.getMinz(),midx,Bucket.getMaxy(),midz,this.col1,this.col2,this.col3);
				children[6] = new Octree(Bucket.getMinx(),Bucket.getMiny(),(midz),midx,midy,Bucket.getMaxz(),this.col1,this.col2,this.col3);
				children[7] = new Octree(Bucket.getMinx(),Bucket.getMiny(),Bucket.getMinz(),midx,midy,midz,this.col1,this.col2,this.col3);
				for (int i = 0  ; i< this.Bucket.getCount() ; i ++) {
					String s2 = this.Bucket.getBucket().get(i) ; 
					Object i2= this.Bucket.getClusteringkeys().get(i) ; 
					OctPoint t2 = this.Bucket.getLocations().get(i) ; 
					int octant = getOctant(t2,midx,midy,midz) ; 
					this.children[octant].insert(t2.getX(), t2.getY(), t2.getZ(), s2, i2);
					for (int j = 0  ; j< this.Bucket.getDuplicates().get(i).size(); j ++) {
						String r1 = Bucket.getDuplicates().get(i).get(j);
						Object r2 = Bucket.getDupObjects().get(i).get(j) ; 			
						OctPoint t3 = this.Bucket.getLocations().get(i) ; 
						int octant3 = getOctant(t3,midx,midy,midz) ; 
						this.children[octant3].insert(t3.getX(), t3.getY(), t3.getZ(), r1, r2);
						
					}
				}
				this.Bucket.setBucket(null);
				this.Bucket.setDupcounts(null);
				this.Bucket.setDuplicates(null);
				this.Bucket.setLocations(null);
				this.Bucket.setClusteringkeys(null);
				this.Bucket.setCount(0);
				OctPoint t3 = new OctPoint (x,y,z) ; 
				int octant2 = getOctant(t3,midx,midy,midz) ; 
				this.children[octant2].insert(x, y, z, s,clusteringKey);
			}
		}
		else {
			OctPoint t3 = new OctPoint (x,y,z) ; 
			int octant2 = getOctant(t3,midx,midy,midz) ; 
			this.children[octant2].insert(x, y, z, s,clusteringKey); }
	}
	public Bucket getBucket() {
		return Bucket;
	}
	public void setBucket(Bucket bucket) {
		Bucket = bucket;
	}
	public Octree<T>[] getChildren() {
		return children;
	}
	public void setChildren(Octree<T>[] children) {
		this.children = children;
	}
	public T getObject() {
		return object;
	}
	public void setObject(T object) {
		this.object = object;
	}
	public String getCol1() {
		return col1;
	}
	public void setCol1(String col1) {
		this.col1 = col1;
	}
	public String getCol2() {
		return col2;
	}
	public void setCol2(String col2) {
		this.col2 = col2;
	}
	public String getCol3() {
		return col3;
	}
	public void setCol3(String col3) {
		this.col3 = col3;
	}
	public boolean find(Object x, Object y, Object z) throws Exception{
		if( ((((Comparable)x).compareTo((Comparable)this.Bucket.getMinx())) < 0) || ((((Comparable)x).compareTo((Comparable)this.Bucket.getMaxx())) > 0)
				||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMiny())) < 0)||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMaxy())) > 0)
				||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMinz())) < 0) ||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMaxz())) > 0))
			return false;
		Object midx = getMidObject(Bucket.getMaxx(),Bucket.getMinx()) ;
		Object midy = getMidObject(Bucket.getMaxy(),Bucket.getMiny()) ;
		Object midz = getMidObject(Bucket.getMaxz(),Bucket.getMinz()) ; 

		OctPoint oct = new OctPoint (x,y,z) ;  
		int pos = getOctant(oct,midx,midy,midz);
		Boolean b = false;

		if(Bucket.getBucket() == null && children[0] != null) 
			return children[pos].find(x, y, z);
		if(Bucket.getCount()==0)
			return false;
		for (int i = 0 ; i < Bucket.getCount() ; i ++ ) {
			b = x.equals(Bucket.getLocations().get(i).getX())&& y.equals(Bucket.getLocations().get(i).getY()) && z.equals(Bucket.getLocations().get(i).getZ());
			if (b) 
				break ;
		}
		return b ;
	}
	
	public void insertintoduplicates(Object x, Object y, Object z,String s, Object clusteringKey) throws Exception{
		if( ((((Comparable)x).compareTo((Comparable)this.Bucket.getMinx())) < 0) || ((((Comparable)x).compareTo((Comparable)this.Bucket.getMaxx())) > 0)
				||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMiny())) < 0)||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMaxy())) > 0)
				||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMinz())) < 0) ||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMaxz())) > 0))
			return; 
		Object midx = getMidObject(Bucket.getMaxx(),Bucket.getMinx()) ;
		Object midy = getMidObject(Bucket.getMaxy(),Bucket.getMiny()) ;
		Object midz = getMidObject(Bucket.getMaxz(),Bucket.getMinz()) ; 
		OctPoint oct = new OctPoint (x,y,z) ;  
		int pos = getOctant(oct,midx,midy,midz);
		Boolean b = false;
		if(Bucket.getBucket() == null && children[0] != null) {
			children[pos].insertintoduplicates(x, y, z,s,clusteringKey) ; }
		if(Bucket.getCount()==0) {
			return ; }
		for (int i = 0 ; i < Bucket.getCount() ; i ++ ) {
			if (Bucket.getLocations() !=null ) {
		
				b = x.equals(Bucket.getLocations().get(i).getX())&& y.equals(Bucket.getLocations().get(i).getY()) && z.equals(Bucket.getLocations().get(i).getZ());
				if (b) 
				{

					Vector <Vector <String>> v = Bucket.getDuplicates() ; 
					Vector <Vector <Object>> dups = Bucket.getDupObjects() ; 
					Vector<Object> dupp = new Vector<Object> () ; 
					
					Vector <String> v2 = new Vector <String> () ; 
					Vector <Integer> v3 = Bucket.getDupcounts(); 
					int iter = v3.get(i)+1 ; 
					if (!v.isEmpty()) {
						v2 = v.get(i) ; }
					else {
						v2 = new Vector <String> () ;
					}
					if (!dups.isEmpty()) {
						dupp = dups.get(i) ; }
					else {
						dupp = new Vector <Object> () ;
					}
					dupp.add(clusteringKey) ; 
					dups.remove(i) ; 
					dups.add(i, dupp);
					Bucket.setDupObjects(dups);
					String ins = s; 
					v2.add(ins) ; 
					v.remove(i) ; 
					v.add(i, v2);
					v3.remove(i) ; 
					v3.add(i,iter) ; 
					Bucket.setDuplicates(v);
					Bucket.setDupcounts(v3);
					
					break ;}
			}}
	}

	public String getPath(Object x, Object y, Object z) throws Exception{
		if( ((((Comparable)x).compareTo((Comparable)this.Bucket.getMinx())) < 0) || ((((Comparable)x).compareTo((Comparable)this.Bucket.getMaxx())) > 0)
				||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMiny())) < 0)||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMaxy())) > 0)
				||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMinz())) < 0) ||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMaxz())) > 0))
			return null;
		Object midx = getMidObject(Bucket.getMaxx(),Bucket.getMinx()) ;
		Object midy = getMidObject(Bucket.getMaxy(),Bucket.getMiny()) ;
		Object midz = getMidObject(Bucket.getMaxz(),Bucket.getMinz()) ; 
		OctPoint oct = new OctPoint (x,y,z) ;  
		int pos = getOctant(oct,midx,midy,midz);
		Boolean b = false;

		if(Bucket.getBucket() == null && children[0] != null)
			return children[pos].getPath(x, y, z);
		if(Bucket.getCount()==0)
			return null;
		for (int i = 0 ; i < Bucket.getCount() ; i ++ ) {
			b =  x.equals(Bucket.getLocations().get(i).getX())&& y.equals(Bucket.getLocations().get(i).getY()) && z.equals(Bucket.getLocations().get(i).getZ());
			if (b) 
				return Bucket.getBucket().get(i) ;}
		return null;
	}
	public Object getObject( Object x, Object y, Object z) throws Exception{
		if( ((((Comparable)x).compareTo((Comparable)this.Bucket.getMinx())) < 0) || ((((Comparable)x).compareTo((Comparable)this.Bucket.getMaxx())) > 0)
				||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMiny())) < 0)||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMaxy())) > 0)
				||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMinz())) < 0) ||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMaxz())) > 0))
			return null;
		Object midx = getMidObject(Bucket.getMaxx(),Bucket.getMinx()) ;
		Object midy = getMidObject(Bucket.getMaxy(),Bucket.getMiny()) ;
		Object midz = getMidObject(Bucket.getMaxz(),Bucket.getMinz()) ; 
		OctPoint oct = new OctPoint (x,y,z) ;  
		int pos = getOctant(oct,midx,midy,midz);
		Boolean b = false;

		if(Bucket.getBucket() == null && children[0] != null)
			return children[pos].getObject(x, y, z);
		if(Bucket.getCount()==0)
			return null;
		for (int i = 0 ; i < Bucket.getCount() ; i ++ ) {
			b =  x.equals(Bucket.getLocations().get(i).getX())&& y.equals(Bucket.getLocations().get(i).getY()) && z.equals(Bucket.getLocations().get(i).getZ());
			if (b) 
				return  Bucket.getClusteringkeys().get(i) ; 
		}
		return null;
	}
	public Vector<String> getdupsPath(Object x, Object y, Object z, String filepath, Object clusteringKey) throws Exception{
		if( ((((Comparable)x).compareTo((Comparable)this.Bucket.getMinx())) < 0) || ((((Comparable)x).compareTo((Comparable)this.Bucket.getMaxx())) > 0)
				||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMiny())) < 0)||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMaxy())) > 0)
				||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMinz())) < 0) ||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMaxz())) > 0))
			return null;
		Object midx = getMidObject(Bucket.getMaxx(),Bucket.getMinx()) ;
		Object midy = getMidObject(Bucket.getMaxy(),Bucket.getMiny()) ;
		Object midz = getMidObject(Bucket.getMaxz(),Bucket.getMinz()) ; 
		OctPoint oct = new OctPoint (x,y,z) ;  
		int pos = getOctant(oct,midx,midy,midz);
		Boolean b = false;

		if(Bucket.getBucket() == null && children[0] != null)
			return children[pos].getdupsPath(x, y, z,filepath,clusteringKey);
		if(Bucket.getCount()==0)
			return null;
		for (int i = 0 ; i < Bucket.getCount() ; i ++ ) {
			b = filepath.equals(Bucket.getBucket().get(i)) && clusteringKey.equals(Bucket.getClusteringkeys().get(i)) &&  x.equals(Bucket.getLocations().get(i).getX())&& y.equals(Bucket.getLocations().get(i).getY()) && z.equals(Bucket.getLocations().get(i).getZ());
			if (b) 
				return Bucket.getDuplicates().get(i) ;
		}
		return null;
	}
	public Vector<Object> getdupsObject(Object x, Object y, Object z, String filepath, Object clusteringKey) throws Exception{
		if( ((((Comparable)x).compareTo((Comparable)this.Bucket.getMinx())) < 0) || ((((Comparable)x).compareTo((Comparable)this.Bucket.getMaxx())) > 0)
				||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMiny())) < 0)||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMaxy())) > 0)
				||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMinz())) < 0) ||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMaxz())) > 0))
			return null;
		Object midx = getMidObject(Bucket.getMaxx(),Bucket.getMinx()) ;
		Object midy = getMidObject(Bucket.getMaxy(),Bucket.getMiny()) ;
		Object midz = getMidObject(Bucket.getMaxz(),Bucket.getMinz()) ; 
		OctPoint oct = new OctPoint (x,y,z) ;  
		int pos = getOctant(oct,midx,midy,midz);
		Boolean b = false;

		if(Bucket.getBucket() == null && children[0] != null)
			return children[pos].getdupsObject(x, y, z,filepath,clusteringKey);
		if(Bucket.getCount()==0)
			return null;
		for (int i = 0 ; i < Bucket.getCount() ; i ++ ) {
			b = filepath.equals(Bucket.getBucket().get(i)) && clusteringKey.equals(Bucket.getClusteringkeys().get(i)) &&  x.equals(Bucket.getLocations().get(i).getX())&& y.equals(Bucket.getLocations().get(i).getY()) && z.equals(Bucket.getLocations().get(i).getZ());
			if (b) 
				return Bucket.getDupObjects().get(i) ; 
		}
		return null;
	}

	public boolean remove(Object x, Object y, Object z) throws Exception{
		if( ((((Comparable)x).compareTo((Comparable)this.Bucket.getMinx())) < 0) || ((((Comparable)x).compareTo((Comparable)this.Bucket.getMaxx())) > 0)
				||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMiny())) < 0)||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMaxy())) > 0)
				||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMinz())) < 0) ||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMaxz())) > 0))
			return false;
		Object midx = getMidObject(Bucket.getMaxx(),Bucket.getMinx()) ;
		Object midy = getMidObject(Bucket.getMaxy(),Bucket.getMiny()) ;
		Object midz = getMidObject(Bucket.getMaxz(),Bucket.getMinz()) ; 
		OctPoint oct = new OctPoint (x,y,z) ;  
		int pos = getOctant(oct,midx,midy,midz);
		Boolean b = false;
		if(Bucket.getBucket()== null && children[0] != null)
			return children[pos].remove(x, y, z);
		if(Bucket.getCount()==0)
			return false;
		for (int i = 0 ; i <Bucket.getCount() ; i ++ ) {
			b =  x.equals(Bucket.getLocations().get(i).getX())&& y.equals(Bucket.getLocations().get(i).getY()) && z.equals(Bucket.getLocations().get(i).getZ());
			if (b) {
				Vector <Vector<String>> v = Bucket.getDuplicates() ; 
				Vector <String> v2 = v.get(i) ; 
				v2 = new Vector <String> () ;
				v.remove(i) ; 
				Vector <Vector<Object>> o = Bucket.getDupObjects() ; 
				o.remove(i) ;
			Bucket.setDupObjects(o);
			 Vector<Integer> o2 = Bucket.getDupcounts() ; 
			o2.remove(i) ;
		Bucket.setDupcounts(o2);
			
				Bucket.setDuplicates(v) ; 
				Bucket.getLocations().remove(i) ; 
				Bucket.getClusteringkeys().remove(i) ; 
				Bucket.getBucket().remove(i) ; 
				Bucket.setCount(Bucket.getCount()-1);
			}
			
		} 
		return false;
	}
	public boolean remove2(Object x, Object y, Object z, String filepath, Object clusteringKey) throws Exception{
		if( ((((Comparable)x).compareTo((Comparable)this.Bucket.getMinx())) < 0) || ((((Comparable)x).compareTo((Comparable)this.Bucket.getMaxx())) > 0)
				||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMiny())) < 0)||  ((((Comparable)y).compareTo((Comparable)this.Bucket.getMaxy())) > 0)
				||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMinz())) < 0) ||  ((((Comparable)z).compareTo((Comparable)this.Bucket.getMaxz())) > 0))
			return false;
		Object midx = getMidObject(Bucket.getMaxx(),Bucket.getMinx()) ;
		Object midy = getMidObject(Bucket.getMaxy(),Bucket.getMiny()) ;
		Object midz = getMidObject(Bucket.getMaxz(),Bucket.getMinz()) ; 
		OctPoint oct = new OctPoint (x,y,z) ;  
		int pos = getOctant(oct,midx,midy,midz);
		Boolean b = false;
		if(Bucket.getBucket() == null && children[0] != null)
			return children[pos].remove2(x, y, z,filepath,clusteringKey);
		if(Bucket.getCount()==0)
			return false;
		for (int i = 0 ; i <Bucket.getCount() ; i ++ ) {

			b = filepath.equals(Bucket.getBucket().get(i)) && clusteringKey.equals(Bucket.getClusteringkeys().get(i)) &&  x.equals(Bucket.getLocations().get(i).getX())&& y.equals(Bucket.getLocations().get(i).getY()) && z.equals(Bucket.getLocations().get(i).getZ());
			if (b) {

				if (Bucket.getDupcounts().get(i)==0) {

					Bucket.getLocations().remove(i) ; 
					Bucket.getClusteringkeys().remove(i) ; 
					Bucket.getBucket().remove(i) ; 
					Bucket.setCount(Bucket.getCount()-1);
				}
				else  { 

					Bucket.getClusteringkeys().remove(i) ; 
					Bucket.getBucket().remove(i) ; 

					
					String r1 = Bucket.getDuplicates().get(i).get(0) ; 
					Object r2 = Bucket.getDupObjects().get(i).get(0) ;
					Bucket.getBucket().add(i,r1) ;
					
					Bucket.getClusteringkeys().add(i,r2) ;
					Vector <Integer> v = Bucket.getDupcounts() ; 
					int num = v.get(i) -1 ; 
					v.remove(i) ; 
					v.add(i,num) ; 
					Bucket.setDupcounts(v);
					Bucket.getDuplicates().get(i).remove(0);
					Bucket.getDupObjects().get(i).remove(0) ; 

				}


				break; 
			}
			Vector <String> bro = Bucket.getDuplicates().get(i) ; 
			if (bro !=null) {
				for (int f = 0 ; f<bro.size() ; f++ ) {
					if (bro.get(f)==null) {
						break;
					}
					else {
						String r1 = bro.get(f) ; 
						Object r2 = Bucket.getDupObjects().get(i).get(f) ; 
						b = filepath.equals(r1) && clusteringKey.equals(r2) &&  x.equals(Bucket.getLocations().get(i).getX())&& y.equals(Bucket.getLocations().get(i).getY()) && z.equals(Bucket.getLocations().get(i).getZ());
						if (b) {
						int g = 	Bucket.getDupcounts().get(i) ; 
						g-- ; 
						Bucket.getDupcounts().remove(i) ; 
						Bucket.getDupcounts().add(i, g);
							Bucket.getDuplicates().get(i).remove(f) ; 
							Bucket.getDupObjects().get(i).remove(f) ; 
							break;

						}
					}
				}
			}

		} 
		return false;
	}

	private static  int  getOctant (OctPoint p , Object midx, Object midy , Object midz ) {
		int pos;

		if(((Comparable)p.getX()).compareTo(((Comparable)midx))<0){
			if(((Comparable)p.getY()).compareTo(((Comparable)midy))<0){
				if(((Comparable)p.getZ()).compareTo(((Comparable)midz))<0)

					pos = 7;
				else
					pos = 6;
			}else{
				if(((Comparable)p.getZ()).compareTo(((Comparable)midz))<0)
					pos = 5;
				else
					pos = 4;
			}
		}else{
			if(((Comparable)p.getY()).compareTo(((Comparable)midy))<0){
				if(((Comparable)p.getZ()).compareTo(((Comparable)midz))<0)
					pos = 3;
				else
					pos = 2;
			}else {
				if(((Comparable)p.getZ()).compareTo(((Comparable)midz))<0)
					pos = 1;
				else
					pos = 0;
			}
		}
		return pos ; 
	}
	public static String getMiddleString(String s, String t)
	{
		return numberToAlphaString((alphaStringToNumber(s)+alphaStringToNumber(t))/2);
	}

	public static long alphaStringToNumber(String str) {
		long n = 0;
		for (char elem : str.toCharArray()) {
			n *= 26;
			n += 1 + (elem - 'a');
		}
		return n;
	}

	public static String numberToAlphaString(long n) {
		StringBuilder r = new StringBuilder();
		while (n > 0) {
			r.append((char)('a' + ( --n % 26) ));
			n /= 26;
		}
		return r.reverse().toString();
	}
	public void display() {
		System.out.println("Index Columns: " + col1 + " " + col2 + " " + col3 );
		System.out.println("--- Octree Structure ---");
		displayNode(this, 0);
	}

	private void displayNode(Octree node, int depth) {
		StringBuilder indent = new StringBuilder();
		for (int i = 0; i < depth; i++) {
			indent.append("\t");
		}
		Boolean b = node.children[0] == null ; 
		System.out.println(indent.toString() + "Node (Leaf: " + b + ")");
		if (node.getBucket()!=null) {
			System.out.println(indent.toString() + "Bounds: " + node.getBucket().displaybounds());}
		else { 
			System.out.println(); 
		}

		if (!b) {
			for (int i = 0; i < 8; i++) {
				System.out.println(indent.toString() + "Child " + i + ":");
				displayNode(node.children[i], depth + 1);
			}
		} else {
			System.out.println(indent.toString() + "Entries:");
			for (int i= 0 ; i< node.Bucket.getCount() ; i++) {
				System.out.println(node.getBucket().getClusteringkeys().toString()) ;  
				System.out.println(indent.toString() + "\t" + node.getBucket().getBucket().get(i) +  "@" + node.getBucket().getClusteringkeys().get(i).toString() +"@" +node.getBucket().getLocations().get(i).display()) ;

			}
			for (int i= 0 ; i< node.Bucket.getCount() ; i++) { 
				int x = i+1 ;
				System.out.println(indent.toString() + "duplicates of entry " + "" + x + ":");
				for (int j = 0 ; j < node.getBucket().getDupcounts().get(i) ; j ++ ) {

					System.out.println(indent.toString() + "\t" + node.getBucket().getDuplicates().get(i).get(j) + "@" +node.getBucket().getDupObjects().get(i).get(j).toString()+ "@" +node.getBucket().getLocations().get(i).display()) ; 
				}
			}}
	}
	public Object getMidObject (Object x, Object y ) throws Exception {
		Object midy; 
		switch (y.getClass().getName()) {
		case "java.lang.String" :
			midy = getMiddleString(x.toString(), y.toString());
			break;
		case "java.lang.Double" :
			midy = ((double)x + (double)y)/2;
			break;
		case "java.lang.Integer" :
			midy = ((Integer)x + (Integer)y)/2;
			break;
		default : //updated
			Date startdate = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy").parse(x.toString()) ; 
			Date enddate =  new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy").parse(y.toString()) ;
			long midwayTime = (startdate.getTime() + enddate.getTime()) / 2;
			Date midwayDate = new Date(midwayTime);
			midy = midwayDate ; 
			break;
		}
		return midy ; 
	}
public Hashtable<String,Object> search (Object x , Object y, Object z, String [] Operators) throws Exception {
	Hashtable<String,Object> result =new Hashtable<String,Object> () ; 
	Queue power = new LinkedList<Octree> () ;
	power.add(this) ;
	while (!power.isEmpty()) {
		Octree cur = (Octree)power.remove() ;
		if (cur.children[0]!=null ) {
			Object midx = getMidObject(cur.Bucket.getMinx(),cur.Bucket.getMaxx());
			Object midy = getMidObject(cur.Bucket.getMiny(),cur.Bucket.getMaxy());
			Object midz = getMidObject(cur.Bucket.getMinz(),cur.Bucket.getMaxz());
			boolean b1 = false;
			boolean b2 = false;
			boolean b3 = false;
			
			b1 = (((Comparable)x).compareTo(((Comparable)midx))>0)  ;
			b2 = (((Comparable)y).compareTo(((Comparable)midy))>0)  ;
			b3 = (((Comparable)z).compareTo(((Comparable)midz))>0)  ;

			boolean b12 = (b1 && (Operators[0].equals(">")|| Operators[0].equals(">="))) || ( (!b1) && (Operators[0].equals("<")|| Operators[0].equals("<=")) ) ||  Operators[0].equals("!=") ;
			boolean b22 = (b2 && (Operators[1].equals(">")|| Operators[1].equals(">="))) || ( (!b2) && (Operators[1].equals("<")|| Operators[1].equals("<=")) ) ||  Operators[1].equals("!=") ;
			boolean b32 = (b3 && (Operators[2].equals(">")|| Operators[2].equals(">="))) || ( (!b3) && (Operators[2].equals("<")|| Operators[2].equals("<=")) ) ||  Operators[2].equals("!=") ;

			if ((b1||b12) && (b2||b22) && (b3||b32)) {power.add(cur.children[0]) ; 
			}
			if ((b1||b12) && (b2||b22) && ((!b3)||b32)) { power.add(cur.children[1]) ;
}
			if ((b1||b12) && ((!b2)||b22) && (b3||b32)) {power.add(cur.children[2]) ; 
		}
			if ((b1||b12) && ((!b2)||b22) && ((!b3)||b32)) {power.add(cur.children[3]) ; 
		}
			if (((!b1)||b12) && (b2||b22) && (b3||b32)) {power.add(cur.children[4]) ; 
			}
			if (((!b1)||b12) && (b2||b22) && ((!b3)||b32)) { power.add(cur.children[5]) ; 
			}
			if (((!b1)||b12) && ((!b2)||b22) && (b3||b32)) { power.add(cur.children[6]) ; 
			}
			if (((!b1)||b12) && ((!b2)||b22) && ((!b3)||b32)) {power.add(cur.children[7]) ; 
		}
		}
		else {
			for (int i = 0 ; i<cur.Bucket.getCount() ; i ++) {
				boolean c1 = true ;
				boolean c2 = true ;
				boolean c3 = true ;	
				c1 = switchhelper(cur.Bucket.getLocations().get(i).getX(),x,Operators[0]) ; 
				c2 = switchhelper(cur.Bucket.getLocations().get(i).getY(),y,Operators[1]) ; 
				c3 = switchhelper(cur.Bucket.getLocations().get(i).getZ(),z,Operators[2]) ; 
				if (c1&&c2&&c3) {
					result.put(cur.Bucket.getBucket().get(i),cur.Bucket.getClusteringkeys().get(i)) ;
					for (int j = 0 ; j < cur.Bucket.getDupcounts().get(i) ; j ++) {
						result.put(cur.Bucket.getDuplicates().get(i).get(j),cur.Bucket.getDupObjects().get(i).get(j)) ; 
					}
				}
			}
		}
		
	}
	return result ; 
}

public boolean switchhelper (Object p , Object x, String operator)  {
	boolean b = true;
	switch (operator ) {
	case "=" :
		b =  p.equals(x) ; 
		break;
	case "<" :
		b =  (((Comparable)p).compareTo(((Comparable)x))<0) ; 
		break;
	case "<=" :
		b =  (((Comparable)p).compareTo(((Comparable)x))<=0) ; 
		break;	
	case ">" :
		b =  (((Comparable)p).compareTo(((Comparable)x))>0) ; 
		break;
	case ">=" :
		b =  (((Comparable)p).compareTo(((Comparable)x))>=0) ; 
		break;
	case "!=" :
		b =  !(p.equals(x)) ; 
		break;	
				
	}
	return b;
}

}