import java.io.IOException;
import java.io.Serializable;
import java.util.Vector;

public class table implements Serializable {
	String name ; 
	Vector <String> pages ;
	int numberofpages ; 
	int count ; 
	int indicescount ; 

	public table(String strTableName) throws IOException {
		
		this.name = strTableName; 
		this.pages = new Vector <String> (); 
		numberofpages = 0  ; 
		indicescount = 0 ; 
	}
	
}
