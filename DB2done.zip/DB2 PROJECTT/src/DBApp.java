import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;
import org.junit.jupiter.api.Assertions;

public class DBApp {
	public void init() {
		String fileName = "metadata";
		File f = new File("src/resources/" + fileName + ".csv");
		if (!f.exists()) {
			try {
				FileOutputStream o = new FileOutputStream("src/resources/" + fileName + ".csv");
				 
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}// this does whatever initialization you would like
	// or leave it empty if there is no code you want to
	// execute at application startup

	public void createTable(String strTableName,
			String strClusteringKeyColumn,
			Hashtable<String,String> htblColNameType,
			Hashtable<String,String> htblColNameMin,
			Hashtable<String,String> htblColNameMax )
					throws DBAppException {
		try {

			FileWriter csvWriter;
			StringBuilder sr = new StringBuilder () ;
			FileReader old = new FileReader ("src/resources/metadata.csv") ;
			BufferedReader br = new BufferedReader(old) ;  
			String curLine ;
			while ((curLine = br.readLine()) !=null ) {
				sr.append(curLine).append("\n") ; 
			}
			csvWriter = new FileWriter("src/resources/metadata.csv");  
			for (String ColName : htblColNameType.keySet()) {
				if (htblColNameType.get(ColName).equals("java.lang.Integer")
						|| htblColNameType.get(ColName).equals("java.lang.String")
						|| htblColNameType.get(ColName).equals("java.lang.Double")
						|| htblColNameType.get(ColName).equals("java.util.Date")) {
					sr.append(strTableName).append(",");
					sr.append(ColName).append(",");
					sr.append(htblColNameType.get(ColName)).append(",");
					sr.append(ColName.equals(strClusteringKeyColumn) ? "True" : "False").append(",");
					sr.append("null,");
					sr.append("null,");
					sr.append(htblColNameMin.get(ColName)).append(",");
					sr.append(htblColNameMax.get(ColName));
					sr.append("\n");
				} else

					throw new DBAppException("Invalid data types");
			}
			csvWriter.append(sr.toString());
			csvWriter.close();
			File Directory = new File("src/resources/" + strTableName + ".ser");
			if (Directory.exists()) {
				throw new DBAppException("Table exists.");
			} else {
				FileOutputStream o;
				o = new FileOutputStream("src/resources/" + strTableName + ".ser");
				ObjectOutputStream out = new ObjectOutputStream(o);
				table ObjectName;
				ObjectName = new table(strTableName);
				Properties config;
				config = new Properties();
				FileInputStream fis;
				fis = new FileInputStream("src/resources/DBApp.config");
				config.load(fis);
				FileOutputStream fileOut;
				fileOut = new FileOutputStream("src/resources/" + strTableName + ".ser");
				ObjectOutputStream out2;
				out2 = new ObjectOutputStream(fileOut);
				out2.writeObject(ObjectName);
				out2.close();
				fileOut.close();
			}}
		catch (Exception E) {
			E.printStackTrace();
			throw new DBAppException(E.getMessage()) ; 
		}
	}

	public void createIndex(String strTableName,
			String[] strarrColName) throws DBAppException{
		try { 
			if (strarrColName.length !=3) {
				throw new DBAppException("Less than 3 columns inserted");
			}
			BufferedReader br;
			br = new BufferedReader(new FileReader("src/resources/metadata.csv"));
			String curLine;
			curLine = br.readLine();
			String clusteringkeyname = "";
			boolean b = false;
			while (curLine != null) {
				String[] metaData = curLine.split(",");
				if (metaData[0].equals(strTableName)) {
					b = true;
					if (metaData[3].equals("True")) {
						clusteringkeyname = metaData[1];
					}
				}
				curLine = br.readLine();
			}
			if (b == false) {
				throw new DBAppException("There is no such table in the database.");
			}
			FileInputStream fileIn;
			fileIn = new FileInputStream("src/resources/" + strTableName + ".ser");
			ObjectInputStream in;
			in = new ObjectInputStream(fileIn);
			table t;
			t = (table) in.readObject();
			in.close();
			fileIn.close();
			FileReader metadata;
			metadata = new FileReader("src/resources/metadata.csv");
			BufferedReader br2 = new BufferedReader(metadata);
			String curLine2;
			curLine2 = br2.readLine();
			Hashtable<String, String> colDataTypes = new Hashtable<>();
			Hashtable<String, Object> colMin = new Hashtable<>();
			Hashtable<String, Object> colMax = new Hashtable<>();
			String clusteringType;
			while (curLine2 != null) {
				String[] res = curLine2.split(",");
				if (res[0].equals(strTableName)) {
					colDataTypes.put(res[1], res[2]);
					switch (res[2]) {
					case "java.lang.Integer":
						colMin.put(res[1], Integer.parseInt(res[6]));
						colMax.put(res[1], Integer.parseInt(res[7]));
						break;
					case "java.lang.Double":
						colMin.put(res[1], Double.parseDouble(res[6]));
						colMax.put(res[1], Double.parseDouble(res[7]));
						break;
					case "java.lang.String":
						colMin.put(res[1], (res[6]));
						colMax.put(res[1], (res[7]));
						break;
					default:
						colMin.put(res[1], new Date(res[6]));
						colMax.put(res[1], new Date(res[7]));
						break;
					}
					if (res[3].equals("True")) {
						clusteringType = res[2];
					}
				}
				curLine2 = br2.readLine();
			}
			int count = 0;
			for (int i = 0; i < strarrColName.length; i++) {
				String s = strarrColName[i];
				if (colDataTypes.containsKey(s) && !(hasindex(strTableName,s))) {
					count++;
				}
			}

			if (count != 3) {
				throw new DBAppException("Less than 3 columns of the table wanted inserted");

			} else {
				updateMetadata2(strarrColName,strTableName) ; 
				String s1 = strarrColName[0];
				String s2 = strarrColName[1];
				String s3 = strarrColName[2];
				Octree oct = new Octree(colMin.get(s1), colMin.get(s2), colMin.get(s3), colMax.get(s1), colMax.get(s2),
						colMax.get(s3), s1, s2, s3);
				for (int i = 0; i < t.numberofpages; i++) {
					page p = getwantedpagebyfilepath(t.pages.get(i));
					for (int j = 0; j < p.numOfRecords; j++) {
						 
						oct.insert(p.records.get(j).get(s1), p.records.get(j).get(s2), p.records.get(j).get(s3),
								t.pages.get(i), p.records.get(j).get(clusteringkeyname));
					}
				}
				FileOutputStream fileOut;
				fileOut = new FileOutputStream(
						"src/resources/"+ s1 + "@" + s2 + "@" + s3 + ".ser");
				ObjectOutputStream out;
				out = new ObjectOutputStream(fileOut);
				out.writeObject(oct);
				out.close();
				fileOut.close();
				t.indicescount ++; 
				updatetableondisk(strTableName, t);
			} }
		catch (Exception e) {
			e.printStackTrace();
			throw new DBAppException(e.getMessage()) ; 
		}
	}

	private boolean hasindex(String strTableName, String s) throws Exception {
		boolean b = false ;
		BufferedReader br;
		br = new BufferedReader(new FileReader("src/resources/metadata.csv"));
		String curLine;
		curLine = br.readLine();

		while (curLine != null) {

			String[] res = curLine.split(",");
			if (!res[0].equals(strTableName)) {
				curLine = br.readLine();
				continue ; 
			}
			if (res[2].equals(s) && !(res[3].equals("null"))) {
				b=true ; 
				break;
			}

			curLine = br.readLine();


		}
		return b ; 
	}
	public void insertIntoTable(String strTableName,
			Hashtable<String,Object> htblColNameValue)
					throws DBAppException {
		try {
			BufferedReader br;
			br = new BufferedReader(new FileReader("src/resources/metadata.csv"));
			String curLine;
			curLine = br.readLine();
			String clusteringkeyname = "";
			boolean b = false;
			while (curLine != null) {
				String[] metaData = curLine.split(",");

				if (metaData[0].equals(strTableName)) {

					b = true;
					if (metaData[3].equalsIgnoreCase("TRUE")) {  
						clusteringkeyname = metaData[1];
					}
				}
				curLine = br.readLine();
			}

			if (b == false) {
				throw new DBAppException("There is no such table in the database.");
			}
			FileInputStream fileIn;
			fileIn = new FileInputStream("src/resources/" + strTableName + ".ser");
			ObjectInputStream in;
			in = new ObjectInputStream(fileIn);
			table t;
			t = (table) in.readObject();
			in.close();
			fileIn.close();
			if (htblColNameValue.get(clusteringkeyname) == null) {
				throw new DBAppException("Primary key can not be null.");
			}
			FileReader metadata;
			metadata = new FileReader("src/resources/metadata.csv");
			BufferedReader br2 = new BufferedReader(metadata);
			String curLine2;
			curLine2 = br2.readLine();
			Hashtable<String, String> colDataTypes = new Hashtable<>();
			Hashtable<String, Object> colMin = new Hashtable<>();
			Hashtable<String, Object> colMax = new Hashtable<>();
			String clusteringType;
			while (curLine2 != null) {
				String[] res = curLine2.split(",");
				if (res[0].equals(strTableName)) {
					colDataTypes.put(res[1], res[2]);
					switch (res[2]) {
					case "java.lang.Integer":
						colMin.put(res[1], Integer.parseInt(res[6]));
						colMax.put(res[1], Integer.parseInt(res[7]));
						break;
					case "java.lang.Double":
						colMin.put(res[1], Double.parseDouble(res[6]));
						colMax.put(res[1], Double.parseDouble(res[7]));
						break;

					case "java.lang.String":
						colMin.put(res[1], (res[6]));
						colMax.put(res[1], (res[7]));
						break;
					default:
						colMin.put(res[1], new Date(res[6]));
						colMax.put(res[1], new Date(res[7]));
						break;
					}
					if (res[3].equals("True")) {
						clusteringType = res[2];

					}
				}

				curLine2 = br2.readLine();

			}

			boolean f2 = false;
			for (Object item : htblColNameValue.keySet()) {
				f2 = false;
				String s = item.toString();
				if (colDataTypes.containsKey(s)) {
					if (htblColNameValue.get(s).getClass().toString().endsWith(colDataTypes.get(s).toString())) {
						f2 = true;
					}

				}
			}

			if (!f2) {
				throw new DBAppException("One or more of the values entered has an incorrect datatype.");
			}

			for (String item : htblColNameValue.keySet()) {
				if (colDataTypes.get(item) != null) {
					if (colDataTypes.get(item).equals(htblColNameValue.get(item).getClass().getName())) {
						switch (colDataTypes.get(item)) {
						case "java.lang.Integer":
							if (((Integer) htblColNameValue.get(item)).compareTo((Integer) colMin.get(item)) < 0) {
								throw new DBAppException("Value for column is less than the minimum allowed");
							}

							if (((Integer) htblColNameValue.get(item)).compareTo((Integer) colMax.get(item)) > 0) {
								throw new DBAppException("Value for column  is greater than the maximum allowed");
							}
							break;
						case "java.lang.Double":
							if (((Double) htblColNameValue.get(item)).compareTo((Double) colMin.get(item)) < 0) {
								throw new DBAppException("Value for column is less than the minimum allowed");
							}
							if (((Double) htblColNameValue.get(item)).compareTo((Double) colMax.get(item)) > 0) {
								throw new DBAppException("Value for column is greater than the maximum allowed");
							}
							break;
						case "java.lang.String":
							if (((String) htblColNameValue.get(item)).compareTo((String) colMin.get(item)) < 0) {
								throw new DBAppException("Value for column is less than the minimum allowed");
							}

							if (((String) htblColNameValue.get(item)).compareTo((String) colMax.get(item)) > 0) {
								throw new DBAppException("Value for column  is greater than the maximum allowed");
							}
							break;

						default:
							if (((Date) htblColNameValue.get(item)).compareTo((Date) colMin.get(item)) < 0) {
								throw new DBAppException("Value for column is less than the minimum allowed");
							}

							if (((Date) htblColNameValue.get(item)).compareTo((Date) colMax.get(item)) > 0) {
								throw new DBAppException("Value for column  is greater than the maximum allowed");
							}
							break;

						}
					} else
						throw new DBAppException("Different datatypes inserted than table structure");
				} else
					throw new DBAppException("Different columns inserted than table structure");
			}

	        if (htblColNameValue.size() < colDataTypes.size()) {
		    	   for (String item : colDataTypes.keySet()) {
		    		   if (htblColNameValue.get(item) == null) {
		    			   Null popo = new Null(); 
		    			   htblColNameValue.put(item, popo) ;
		    		   }
		    	   }
		       }

			if (t.numberofpages == 0) {
				page p;
				p = new page();
				Properties config;
				config = new Properties();
				FileInputStream fis;
				fis = new FileInputStream("src/resources/DBApp.config");
				config.load(fis);
				p.maxsize = Integer.parseInt(config.getProperty("MaximumRowsCountinTablePage"));
				FileOutputStream fileOut;
				fileOut = new FileOutputStream("src/resources/" + strTableName + "1" + ".ser");
				ObjectOutputStream out;
				out = new ObjectOutputStream(fileOut);
				out.writeObject(p);
				out.close();
				fileOut.close();
				p.max = htblColNameValue.get(clusteringkeyname);
				p.min = htblColNameValue.get(clusteringkeyname);
				p.records.add(htblColNameValue);
				p.numOfRecords++;
				t.pages.add(getfilepath(strTableName, 0));
				t.numberofpages++;
				t.count++;

				ArrayList<String> r = getindexnames(strTableName) ; 
				for (int l = 0; l < r.size(); l++) {
					
					Object x = null;
					String[] que = r.get(l).split("@");
					String r1 = que[0];
					String r2 = que[1];
					String r3 = que[2];
					String path = "src/resources/"+ r1 + "@" + r2 + "@" + r3 + ".ser";
					x = getObj1(path, htblColNameValue);
					Object y = null;
					y = getObj2(path, htblColNameValue);
					Object z = null;
					z = getObj3(path , htblColNameValue); 
					insertintoOctree(path, getfilepath(strTableName, 0), htblColNameValue.get(clusteringkeyname), x, y, z);
				}

				updatetableondisk(strTableName, t);
				updatepageondisk(strTableName, 1, p);

			} else {

				int pagenum;
				pagenum = pageBinarySearch(t.pages, htblColNameValue, clusteringkeyname, t.numberofpages);
				page p;
				p = getwantedpage(strTableName, pagenum);
				int recnum = binarysearchinsertion(p.records, htblColNameValue, clusteringkeyname);
				if (BinarySearch(p.records, htblColNameValue, clusteringkeyname) != -1
						|| compare2objects(htblColNameValue.get(clusteringkeyname), p.min) == 0
						|| compare2objects(htblColNameValue.get(clusteringkeyname), p.max) == 0) {
					throw new DBAppException("Duplicate records are not allowed.");
				} else {

					if (p.numOfRecords < p.maxsize) {
						p.records.add(recnum, htblColNameValue);
						t.count++;
						p.numOfRecords++;
						t.pages.remove(pagenum);
						t.pages.add(getfilepath(strTableName, pagenum));
						p.max = p.records.get(p.numOfRecords - 1).get(clusteringkeyname);
						p.min = p.records.get(0).get(clusteringkeyname);
						ArrayList<String> sherby = getindexnames(strTableName) ; 
						for (int l = 0; l < sherby.size(); l++) {
							Object x = null;
							String[] que = sherby.get(l).split("@");
							String r1 = que[0];
							String r2 = que[1];
							String r3 = que[2];
							String path = "src/resources/"+ r1 + "@" + r2 + "@" + r3 + ".ser";
							x = getObj1(path, htblColNameValue);
							Object y = null;
							y = getObj2(path, htblColNameValue);
							Object z = null;
							z = getObj3(path , htblColNameValue);
							insertintoOctree(path, getfilepath(strTableName, pagenum), htblColNameValue.get(clusteringkeyname), x, y, z);
						}			
						updatetableondisk(strTableName, t);
						updatepageondisk(strTableName, pagenum + 1, p);
					} else {
						if (p.numOfRecords == p.maxsize) {
							page p2;
							p2 = new page();
							Properties config;
							config = new Properties();
							FileInputStream fis;
							fis = new FileInputStream("src/resources/DBApp.config");
							config.load(fis);
							p2.maxsize = Integer.parseInt(config.getProperty("MaximumRowsCountinTablePage"));
							FileOutputStream fileOut;
							if (t.numberofpages - 1 == pagenum) {
								int w = pagenum + 2;
								fileOut = new FileOutputStream("src/resources/" + strTableName + "" + w + "" + ".ser");
								ObjectOutputStream out;
								out = new ObjectOutputStream(fileOut);
								out.writeObject(p2);
								out.close();
								fileOut.close();
								t.pages.add(getfilepath(strTableName, pagenum));
								t.numberofpages++;
								updatetableondisk(strTableName, t);
							}
							if (recnum >= p.maxsize) {
								insertintonextpage(htblColNameValue, pagenum + 1, strTableName, clusteringkeyname);			
							}
							else {
								Hashtable<String, Object> you = p.records.remove(p.maxsize - 1);
								ArrayList<String> sh = getindexnames(strTableName) ; 
								for (int l = 0; l < sh.size(); l++) {
									Object x = null;
									String[] que = sh.get(l).split("@");
									String r1 = que[0];
									String r2 = que[1];
									String r3 = que[2];
									String path = "src/resources/"+ r1 + "@" + r2 + "@" + r3 + ".ser";
									x = getObj1(path, you);
									Object y = null;
									y = getObj2(path, you);
									Object z = null;
									z = getObj3(path , you);
									removefromOctree(path, getfilepath(strTableName, pagenum),you.get(clusteringkeyname), x, y, z);

								}		

								p.records.add(recnum, htblColNameValue);
								p.max = p.records.get(p.numOfRecords - 1).get(clusteringkeyname);
								p.min = p.records.get(0).get(clusteringkeyname);
								t.pages.remove(pagenum);
								t.pages.add(pagenum, getfilepath(strTableName, pagenum));
								updatetableondisk(strTableName, t);
								updatepageondisk(strTableName, pagenum + 1, p);
								ArrayList<String> r20 = getindexnames(strTableName) ; 
								for (int l = 0; l < r20.size(); l++) {
									Object x = null;
									String[] que = r20.get(l).split("@");
									String r1 = que[0];
									String r2 = que[1];
									String r3 = que[2];
									String path = "src/resources/"+ r1 + "@" + r2 + "@" + r3 + ".ser";
									x = getObj1(path, htblColNameValue);
									Object y = null;
									y = getObj2(path, htblColNameValue);
									Object z = null;
									z = getObj3(path , htblColNameValue);
									insertintoOctree(path, getfilepath(strTableName, pagenum), htblColNameValue.get(clusteringkeyname), x, y,
											z);

								}		

								insertintonextpage(you, pagenum + 1, strTableName, clusteringkeyname);
							}
						}
					}
				}
			}}
		catch (Exception e) {
			e.printStackTrace();
			throw new DBAppException(e.getMessage() ) ; 
		}
	}

	private void insertintonextpage(Hashtable<String, Object> you, int i, String strTableName, String clusteringkeyname)
			throws Exception {
		int x = i + 1;
		page p2 = new page();
		boolean z = false;
		String fileName = strTableName + "" + x;
		File f = new File("src/resources/" + fileName + ".ser");
		if (!f.exists()) {
			z = true;
			FileOutputStream o = new FileOutputStream("src/resources/" + fileName + ".ser");
			ObjectOutputStream out = new ObjectOutputStream(o);
			Properties config;
			config = new Properties();
			FileInputStream fis;
			fis = new FileInputStream("src/resources/DBApp.config");
			config.load(fis);
			p2.maxsize = Integer.parseInt(config.getProperty("MaximumRowsCountinTablePage"));
			out.writeObject(p2);
			out.close();
			o.close();
		}
		FileInputStream fileIn = new FileInputStream("src/resources/" + strTableName + x + ".ser");
		ObjectInputStream in = new ObjectInputStream(fileIn);
		page p = (page) in.readObject();
		in.close();
		fileIn.close();
		FileInputStream fileIn2 = new FileInputStream("src/resources/" + strTableName + ".ser");
		ObjectInputStream in2 = new ObjectInputStream(fileIn2);
		table t = (table) in2.readObject();
		in2.close();
		fileIn2.close();
		if (z) {
			t.pages.add(getfilepath(strTableName, i));
			t.numberofpages++;
		}
		if (p.numOfRecords < p.maxsize) {
			p.records.add(0, you);
			p.numOfRecords++;
			p.max = p.records.get(p.numOfRecords - 1).get(clusteringkeyname);
			p.min = p.records.get(0).get(clusteringkeyname);
			updatepageondisk(strTableName, x, p);
			t.count++;
			t.pages.remove(i);
			t.pages.add(i, getfilepath(strTableName, i));
			updatetableondisk(strTableName, t);
			ArrayList<String> r20 = getindexnames(strTableName) ; 
			for (int l = 0; l < r20.size(); l++) {
				Object x5 = null;
				String[] que = r20.get(l).split("@");
				String r1 = que[0];
				String r2 = que[1];
				String r3 = que[2];
				String path = "src/resources/"+ r1 + "@" + r2 + "@" + r3 + ".ser";
				x5 = getObj1(path, you);
				Object y5 = null;
				y5 = getObj2(path, you);
				Object z5 = null;
				z5 = getObj3(path , you);
				insertintoOctree(path, getfilepath(strTableName, i), you.get(clusteringkeyname), x5, y5, z5);

			}		

		} else {
			Hashtable<String, Object> you2 = p.records.remove(p.maxsize - 1);
			ArrayList<String> r20 = getindexnames(strTableName) ; 
			for (int l = 0; l < r20.size(); l++) {
				Object x6 = null;
				String[] que = r20.get(l).split("@");
				String r1 = que[0];
				String r2 = que[1];
				String r3 = que[2];
				String path = "src/resources/"+ r1 + "@" + r2 + "@" + r3 + ".ser";
				x6 = getObj1(path, you2);
				Object y6 = null;
				y6 = getObj2(path, you2);
				Object z6 = null;
				z6 = getObj3(path , you2);
				removefromOctree(path, getfilepath(strTableName, i), you2.get(clusteringkeyname), x6, y6, z6);

			}		

			p.records.add(0, you);
			p.max = p.records.get(p.numOfRecords - 1).get(clusteringkeyname);
			p.min = p.records.get(0).get(clusteringkeyname);
			updatepageondisk(strTableName, i, p);
			t.pages.remove(i - 1);
			t.pages.add(i - 1, getfilepath(strTableName, i - 1));
			updatetableondisk(strTableName, t);
			ArrayList<String> r = getindexnames(strTableName) ; 
			for (int l = 0; l < r.size(); l++) {
				Object x6 = null;
				String[] que = r.get(l).split("@");
				String r1 = que[0];
				String r2 = que[1];
				String r3 = que[2];
				String path = "src/resources/"+ r1 + "@" + r2 + "@" + r3+ ".ser";
				x6 = getObj1(path, you2);
				Object y6 = null;
				y6 = getObj2(path, you2);
				Object z6 = null;
				z6 = getObj3(path , you2);
				insertintoOctree(path, getfilepath(strTableName, i), you2.get(clusteringkeyname), x6, y6, z6);

			}		
			insertintonextpage(you2, i + 1, strTableName, clusteringkeyname);
		}
	}
	private static int binarysearchinsertion(Vector<Hashtable<String, Object>> p, Hashtable<String, Object> htbl,
			String clusteringkey) {
		int l = 0;
		int r = p.size() - 1;
		while (l <= r) {
			int m = l + (r - l) / 2;
			if (htbl.equals(p.get(m)))
				return m;
			if (compare2objects(htbl.get(clusteringkey), p.get(m).get(clusteringkey)) > 0)
				l = m + 1;
			else
				r = m - 1;
		}
		return l;

	}

	private void updatepageondisk(String strTableName, int pagenum, page p) {
		File f = new File("src/resources/" + strTableName + pagenum + ".ser");
		f.delete();
		FileOutputStream fileOut;
		try {
			fileOut = new FileOutputStream("src/resources/" + strTableName + pagenum + ".ser");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(p);
			out.close();
			fileOut.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void updatetableondisk(String strTableName, table t) {

		File f = new File("src/resources/" + strTableName + ".ser");
		f.delete();
		FileOutputStream fileOut;
		try {
			fileOut = new FileOutputStream("src/resources/" + strTableName + ".ser");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(t);
			out.close();
			fileOut.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void updateTable(String strTableName,
			String strClusteringKeyValue,
			Hashtable<String,Object> htblColNameValue )
					throws DBAppException{
		try {
			if (strClusteringKeyValue == "") {
				throw new DBAppException("Please enter the primary key of the record you want to update");
			}
			BufferedReader br;
			br = new BufferedReader(new FileReader("src/resources/metadata.csv"));
			String curLine;
			curLine = br.readLine();
			String clusteringkeyname = "";
			boolean b = false;
			while (curLine != null) {
				String[] metaData = curLine.split(",");
				if (metaData[0].equals(strTableName)) {
					b = true;
					if (metaData[3].equalsIgnoreCase("True")) {
						clusteringkeyname = metaData[1];
					}
				}
				curLine = br.readLine();
			}
			if (b == false) {
				throw new DBAppException("There is no such table in the database.");
			}
			FileInputStream fileIn;

			fileIn = new FileInputStream("src/resources/" + strTableName + ".ser");
			ObjectInputStream in;
			in = new ObjectInputStream(fileIn);
			table t;
			t = (table) in.readObject();
			in.close();
			fileIn.close();
			FileReader metadata;
			metadata = new FileReader("src/resources/metadata.csv");
			BufferedReader br2 = new BufferedReader(metadata);
			String curLine2;
			curLine2 = br2.readLine();
			Hashtable<String, String> colDataTypes = new Hashtable<>();
			Hashtable<String, Object> colMin = new Hashtable<>();
			Hashtable<String, Object> colMax = new Hashtable<>();
			String clusteringType = null;
			while (curLine2 != null) {
				String[] res = curLine2.split(",");
				if (res[0].equals(strTableName)) {
					colDataTypes.put(res[1], res[2]);
					switch (res[2]) {
					case "java.lang.Integer":
						colMin.put(res[1], Integer.parseInt(res[6]));
						colMax.put(res[1], Integer.parseInt(res[7]));
						break;
					case "java.lang.Double":
						colMin.put(res[1], Double.parseDouble(res[6]));
						colMax.put(res[1], Double.parseDouble(res[7]));
						break;

					case "java.lang.String":
						colMin.put(res[1], (res[6]));
						colMax.put(res[1], (res[7]));
						break;
					default:
						colMin.put(res[1], new Date(res[6]));
						colMax.put(res[1], new Date(res[7]));
						break;
					}
					if (res[3].equalsIgnoreCase("True")) {
						clusteringType = res[2];
					}
				}

				curLine2 = br2.readLine();
			}
			boolean f2 = false;
			for (Object item : htblColNameValue.keySet()) {
				f2 = false;
				String s = item.toString();
				if (colDataTypes.containsKey(s)) {
					if (htblColNameValue.get(s).getClass().toString().endsWith(colDataTypes.get(s).toString())) {
						f2 = true;
					}
				}
			}
			if (!f2) {
				throw new DBAppException("One or more of the values entered has an incorrect datatype.");
			}
			for (String item : htblColNameValue.keySet()) {
				if (colDataTypes.get(item) != null) {
					if (colDataTypes.get(item).equals(htblColNameValue.get(item).getClass().getName())) {
						switch (colDataTypes.get(item)) {
						case "java.lang.Integer":
							if (((Integer) htblColNameValue.get(item)).compareTo((Integer) colMin.get(item)) < 0) {
								throw new DBAppException("Value for column is less than the minimum allowed");
							}

							if (((Integer) htblColNameValue.get(item)).compareTo((Integer) colMax.get(item)) > 0) {
								throw new DBAppException("Value for column  is greater than the maximum allowed");
							}
							break;
						case "java.lang.Double":
							if (((Double) htblColNameValue.get(item)).compareTo((Double) colMin.get(item)) < 0) {
								throw new DBAppException("Value for column is less than the minimum allowed");
							}
							if (((Double) htblColNameValue.get(item)).compareTo((Double) colMax.get(item)) > 0) {
								throw new DBAppException("Value for column is greater than the maximum allowed");
							}
							break;
						case "java.lang.String":
							if (((String) htblColNameValue.get(item)).compareTo((String) colMin.get(item)) < 0) {
								throw new DBAppException("Value for column is less than the minimum allowed");
							}

							if (((String) htblColNameValue.get(item)).compareTo((String) colMax.get(item)) > 0) {
								throw new DBAppException("Value for column  is greater than the maximum allowed");
							}
							break;

						default:
							if (((Date) htblColNameValue.get(item)).compareTo((Date) colMin.get(item)) < 0) {
								throw new DBAppException("Value for column is less than the minimum allowed");
							}

							if (((Date) htblColNameValue.get(item)).compareTo((Date) colMax.get(item)) > 0) {
								throw new DBAppException("Value for column  is greater than the maximum allowed");
							}
							break;
						}
					} else
						throw new DBAppException("Column data types entered does not match the table structure");
				} else
					throw new DBAppException("Columns entered does not match the table structure");
			}
			for (String item : htblColNameValue.keySet()) {
				if (item.equals(clusteringkeyname))
					throw new DBAppException("You are not allowed to update the clsutering key column");
			}
			int pagenum;
			pagenum = pageBinarySearch2(t.pages, strClusteringKeyValue, clusteringkeyname, t.numberofpages,
					clusteringType);
			page p;
			p = getwantedpage(strTableName, pagenum);
			int recnum;

			recnum = BinarySearch2(p.records, strClusteringKeyValue, p.numOfRecords, clusteringkeyname, clusteringType);
			if (recnum >= 0) {
				Hashtable<String, Object> you = p.records.get(recnum);
				Hashtable<String, Object> delete = new Hashtable();
				switch (clusteringType) {
				case "java.lang.Integer":
					int x = Integer.parseInt(strClusteringKeyValue);
					delete.put(clusteringkeyname, x);
					break;
				case "java.lang.Double":
					Double y = Double.parseDouble(strClusteringKeyValue);
					delete.put(clusteringkeyname, y);
					break;
				case "java.lang.String":
					String w = strClusteringKeyValue;
					delete.put(clusteringkeyname, w);
					break;
				default:
					Date d;
					d = new SimpleDateFormat("yyyy-MM-dd").parse(strClusteringKeyValue);
					delete.put(clusteringkeyname, d);
					break;
				}
				int pagenum2;
				pagenum2 = pageBinarySearch2(t.pages, strClusteringKeyValue, clusteringkeyname, t.numberofpages,
						clusteringType);
				page p2;
				p2 = getwantedpage(strTableName, pagenum2);
				int recnum2;
				recnum2 = BinarySearch2(p2.records, strClusteringKeyValue, p2.numOfRecords, clusteringkeyname,
						clusteringType);
				if (recnum2 >= 0) {
					p2.records.remove(recnum2);
					p2.numOfRecords--;
					t.count--;
					t.pages.remove(pagenum2);
					t.pages.add(pagenum2, getfilepath(strTableName, pagenum2));
					updatepageondisk(strTableName, pagenum2 + 1, p2);
					updatetableondisk(strTableName, t);
					ArrayList<String> r = getindexnames(strTableName) ; 
					for (int l = 0; l < r.size(); l++) {
						Object x6 = null;
						String[] que = r.get(l).split("@");
						String r1 = que[0];
						String r2 = que[1];
						String r3 = que[2];
						String path = "src/resources/"+ r1 + "@" + r2 + "@" + r3+ ".ser";
						x6 = getObj1(path, you);
						Object y6 = null;
						y6 = getObj2(path, you);
						Object z6 = null;
						z6 = getObj3(path , you);
						removefromOctree(path, getfilepath(strTableName, pagenum2), you.get(clusteringkeyname), x6, y6, z6);

					}		

				} else
					throw new DBAppException("record not found");

				for (String item : htblColNameValue.keySet()) {
					you.replace(item, you.get(item), htblColNameValue.get(item));
				}
				p2.records.add(recnum2, you);
				p2.numOfRecords++;
				t.count++;
				t.pages.remove(pagenum2);
				t.pages.add(pagenum2, getfilepath(strTableName, pagenum2));
				updatepageondisk(strTableName, pagenum2 + 1, p2);
				updatetableondisk(strTableName, t);
				ArrayList<String> r = getindexnames(strTableName) ; 
				for (int l = 0; l < r.size(); l++) {
					Object x6 = null;
					String[] que = r.get(l).split("@");
					String r1 = que[0];
					String r2 = que[1];
					String r3 = que[2];
					String path = "src/resources/"+ r1 + "@" + r2 + "@" + r3 + ".ser";
					x6 = getObj1(path, you);
					Object y6 = null;
					y6 = getObj2(path, you);
					Object z6 = null;
					z6 = getObj3(path , you);
					
					insertintoOctree(path, getfilepath(strTableName, pagenum2), you.get(clusteringkeyname), x6, y6, z6);

				}		

			} else
				throw new DBAppException("record not found"); }
		catch (Exception e ) {
			e.printStackTrace();
			throw new DBAppException(e.getMessage()) ; 
		}
	}

	private int BinarySearch2(Vector<Hashtable<String, Object>> page, String strClusteringKeyValue, int pagecount,
			String clusteringkeyname, String clusteringType) throws ParseException {
		switch (clusteringType) {
		case "java.lang.Integer":
			int x = Integer.parseInt(strClusteringKeyValue);

			int lb = 0, ub = pagecount - 1;
			while (lb <= ub) {
				int m = (lb + ub) / 2;

				int x2 = (Integer) page.get(m).get(clusteringkeyname);
				
				if (x == x2) {

					return m;
				}

				if ((compare2objects(x, x2) > 0))
					lb = m + 1;

				else
					ub = m - 1;
			}

			return -1;

		case "java.lang.Double":
			Double y = Double.parseDouble(strClusteringKeyValue);

			lb = 0;
			ub = pagecount - 1;
			while (lb <= ub) {
				int m = (lb + ub) / 2;
				Double y2 = (Double) page.get(m).get(clusteringkeyname);
				if (y == y2)
					return m;

				if ((compare2objects(y, y2) > 0))
					lb = m + 1;

				else
					ub = m - 1;
			}

			return -1;

		case "java.lang.String":
			String z = strClusteringKeyValue;
			lb = 0;
			ub = pagecount - 1;
			while (lb <= ub) {
				int m = (lb + ub) / 2;
				String z2 = page.get(m).get(clusteringkeyname).toString();
				if (z.equals(z2))
					return m;

				if ((compare2objects(z, z2) > 0))
					lb = m + 1;

				else
					ub = m - 1;
			}

			return -1;

		default:
			Date d = new SimpleDateFormat("yyyy-MM-dd").parse(strClusteringKeyValue);

			lb = 0;
			ub = pagecount - 1;
			while (lb <= ub) {
				int m = (lb + ub) / 2;
				Date d2 = (Date) page.get(m).get(clusteringkeyname);
				if (d == d2)
					return m;

				if ((compare2objects(d, d2) > 0))
					lb = m + 1;

				else
					ub = m - 1;
			}

			return -1;

		}
	}

	private int pageBinarySearch2(Vector<String> pages, String strClusteringKeyValue, String clusteringkeyname,
			int pagecount, String clusteringType) throws ParseException, ClassNotFoundException, IOException {
		switch (clusteringType) {
		case "java.lang.Integer":
			int x = Integer.parseInt(strClusteringKeyValue);
			int lb = 0, ub = pagecount - 1;
			while (lb <= ub) {

				int m = (lb + ub) / 2;
				page p = getwantedpagebyfilepath(pages.get(m));

				if ((compare2objects(x, p.min)) >= 0 && (compare2objects(x, p.max)) <= 0) {
					return m;
				}

				if ((compare2objects(x, p.max)) > 0)
					lb = m + 1;
				else
					ub = m - 1;
			}
			return -1;

		case "java.lang.Double":
			Double y = Double.parseDouble(strClusteringKeyValue);
			lb = 0;
			ub = pagecount - 1;
			while (lb <= ub) {
				int m = (lb + ub) / 2;
				page p = getwantedpagebyfilepath(pages.get(m));
				if ((compare2objects(y, p.min)) > 0 && (compare2objects(y, p.max)) < 0)
					return m;

				if ((compare2objects(y, p.max)) > 0)
					lb = m + 1;
				else
					ub = m - 1;
			}
			return -1;

		case "java.lang.String":
		
			String w = strClusteringKeyValue;
			lb = 0;
			ub = pagecount - 1;
			while (lb <= ub) {
				int m = (lb + ub) / 2;
				page p = getwantedpagebyfilepath(pages.get(m));
				if ((compare2objects(w, p.min)) > 0 && (compare2objects(w, p.max)) < 0)
					return m;

				if ((compare2objects(w, p.max)) > 0)
					lb = m + 1;
				else
					ub = m - 1;
			}
			return -1;

		default:
			Date d = new SimpleDateFormat("yyyy-MM-dd").parse(strClusteringKeyValue);
			lb = 0;
			ub = pagecount - 1;
			while (lb <= ub) {
				int m = (lb + ub) / 2;
				page p = getwantedpagebyfilepath(pages.get(m));
				if ((compare2objects(d, p.min)) > 0 && (compare2objects(d, p.max)) < 0)
					return m;

				if ((compare2objects(d, p.max)) > 0)
					lb = m + 1;
				else
					ub = m - 1;
			}
			return -1;

		}

	}

	public void deleteFromTable(String strTableName,
			Hashtable<String,Object> htblColNameValue)
					throws DBAppException{
		try {
			BufferedReader br;
			br = new BufferedReader(new FileReader("src/resources/metadata.csv"));
			String curLine;
			curLine = br.readLine();
			String clusteringkeyname = "";
			boolean b = false;
			while (curLine != null) {
				String[] metaData = curLine.split(",");
				if (metaData[0].equals(strTableName)) {
					b = true;
					if (metaData[3].equals("True")) {
						clusteringkeyname = metaData[1];
					}
				}
				curLine = br.readLine();
			}
			if (b == false) {
				throw new DBAppException("There is no such table in the database.");
			}
			FileInputStream fileIn;
			fileIn = new FileInputStream("src/resources/" + strTableName + ".ser");
			ObjectInputStream in;
			in = new ObjectInputStream(fileIn);
			table t;
			t = (table) in.readObject();
			in.close();
			fileIn.close();
			FileReader metadata;
			metadata = new FileReader("src/resources/metadata.csv");
			BufferedReader br2 = new BufferedReader(metadata);
			String curLine2;
			curLine2 = br2.readLine();
			Hashtable<String, String> colDataTypes = new Hashtable<>();
			Hashtable<String, Object> colMin = new Hashtable<>();
			Hashtable<String, Object> colMax = new Hashtable<>();
			String clusteringType = null;
			while (curLine2 != null) {
				String[] res = curLine2.split(",");
				if (res[0].equals(strTableName)) {
					colDataTypes.put(res[1], res[2]);
					switch (res[2]) {
					case "java.lang.Integer":
						colMin.put(res[1], Integer.parseInt(res[6]));
						colMax.put(res[1], Integer.parseInt(res[7]));
						break;
					case "java.lang.Double":
						colMin.put(res[1], Double.parseDouble(res[6]));
						colMax.put(res[1], Double.parseDouble(res[7]));
						break;

					case "java.lang.String":
						colMin.put(res[1], (res[6]));
						colMax.put(res[1], (res[7]));
						break;
					default:
						colMin.put(res[1], new Date(res[6]));
						colMax.put(res[1], new Date(res[7]));
						break;
					}
					if (res[3].equals("True")) {
						clusteringType = res[2];
					}
				}
				curLine2 = br2.readLine();
			}
			boolean f2 = false;
			for (Object item : htblColNameValue.keySet()) {
				f2 = false;
				String s = item.toString();
				if (colDataTypes.containsKey(s)) {
					if (htblColNameValue.get(s).getClass().toString().endsWith(colDataTypes.get(s).toString())) {
						f2 = true;
					}
				}
			}
			if (!f2) {
				throw new DBAppException("One or more of the values entered has an incorrect datatype.");
			}
			Boolean flag = false;

			ArrayList<String> r = getindexnames(strTableName) ; 
			String path2 = "" ; 
			for (int i = 0; i < r.size(); i++) {

				String[] que = r.get(i).split("@");
				String str1 = que[0];
				String str2 = que[1];
				String str3 = que[2];
				int count = 0;
				for (Object item : htblColNameValue.keySet()) {
					if (item.toString().equals(str1) || item.toString().equals(str2) || item.toString().equals(str3)) {
						count++;
					}
				}

				if (count == 3) {
					flag = true;
					path2 = "src/resources/"+ str1 + "@" + str2 + "@" + str3  + ".ser";
					break;
				}
			}

			if (flag) {
				Octree mango = null ;
				FileInputStream  farida = new FileInputStream(path2);
				ObjectInputStream farida2 = new ObjectInputStream(farida) ;

				mango = (Octree) farida2.readObject();
				farida2.close();
				farida.close();
				String str1 = mango.getCol1();
				String str2 = mango.getCol2();
				String str3 = mango.getCol3();
				while (true) {
					if (mango.find(htblColNameValue.get(str1), htblColNameValue.get(str2), htblColNameValue.get(str3))) {
						String r10 = mango.getPath(htblColNameValue.get(str1), htblColNameValue.get(str2),
								htblColNameValue.get(str3));
						Object r2 = mango.getObject(htblColNameValue.get(str1), htblColNameValue.get(str2),
								htblColNameValue.get(str3));
						Hashtable <String,Object> toUse = new Hashtable<String,Object> (); 
						toUse.put(clusteringkeyname, r2) ; 
						Vector <String> dups = mango.getdupsPath(htblColNameValue.get(str1), htblColNameValue.get(str2),
								htblColNameValue.get(str3),r10,r2);
						Vector <Object> dupObjects = mango.getdupsObject(htblColNameValue.get(str1), htblColNameValue.get(str2),
								htblColNameValue.get(str3),r10,r2);
						mango.remove(htblColNameValue.get(str1), htblColNameValue.get(str2), htblColNameValue.get(str3));
						File f = new File(path2);
						f.delete();
						FileOutputStream fileOut;
						try {
							fileOut = new FileOutputStream(path2);
							ObjectOutputStream out = new ObjectOutputStream(fileOut);
							out.writeObject(mango);
							out.close();
							fileOut.close();
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						//update here

						page p = getwantedpagebyfilepath(r10);
						int recordnumber = BinarySearch3(p.records,toUse,clusteringkeyname) ; 
						p.records.remove(recordnumber);
						p.numOfRecords--;
						t.count--;
						int pagenum = getpagenum(strTableName, r10);
						if (p.numOfRecords == 0) {
							t.pages.remove(pagenum);
							t.numberofpages--;
							File f6 = new File("src/resources/" + strTableName + pagenum + ".ser");
							f6.delete();
							updatetableondisk(strTableName, t);
						} else {
							p.max = p.records.get(p.numOfRecords - 1).get(clusteringkeyname);
							p.min = p.records.get(0).get(clusteringkeyname);
							t.pages.remove(pagenum);
							t.pages.add(pagenum, getfilepath(strTableName, pagenum));
							updatepageondisk(strTableName, pagenum + 1, p);
							updatetableondisk(strTableName, t);

						}

						for (int i = 0 ; i < dups.size() ; i++) {
							String dup = dups.get(i) ; 
							Object dup2 = dupObjects.get(i) ; 
							toUse.clear(); 
							toUse.put(clusteringkeyname, dup2) ; 
							page pdup = getwantedpagebyfilepath(dup);

							int duprecordnumber = BinarySearch3(pdup.records,toUse,clusteringkeyname) ; 
							pdup.records.remove(duprecordnumber);
							pdup.numOfRecords--;
							t.count--;
							int duppagenum = getpagenum(strTableName, dup);
							if (pdup.numOfRecords == 0) {

								t.pages.remove(duppagenum);
								t.numberofpages--;
								duppagenum++; 
								File f6 = new File("src/resources/" + strTableName + duppagenum + ".ser");
								f6.delete();
								updatetableondisk(strTableName, t);
							} else {
								pdup.max = pdup.records.get(pdup.numOfRecords - 1).get(clusteringkeyname);
								pdup.min = pdup.records.get(0).get(clusteringkeyname);
								t.pages.remove(duppagenum);
								t.pages.add(duppagenum, getfilepath(strTableName, duppagenum));
								updatepageondisk(strTableName, duppagenum + 1, p);
								updatetableondisk(strTableName, t);

							}
						}
					} else
						return;
				}
			}

			else {
				int size = htblColNameValue.size();
				boolean f3 = htblColNameValue.containsKey(clusteringkeyname);

				if (size == 1 && f3) {
					int pagenum;
					pagenum = pageBinarySearch2(t.pages, htblColNameValue.get(clusteringkeyname).toString(),
							clusteringkeyname, t.numberofpages, clusteringType);
					page p;
					p = getwantedpage(strTableName, pagenum);
					int recnum;
					recnum = BinarySearch2(p.records, htblColNameValue.get(clusteringkeyname).toString(),
							p.numOfRecords, clusteringkeyname, clusteringType);
					if (recnum >= 0) {
						Hashtable <String,Object > you = p.records.get(recnum) ; 
						p.records.remove(recnum);
						p.numOfRecords--;
						t.count--;
						t.pages.remove(pagenum);
						t.pages.add(pagenum, getfilepath(strTableName, pagenum));
						ArrayList<String> rx = getindexnames(strTableName) ; 

						for (int l = 0; l < rx.size(); l++) {
							Object x6 = null;
							String[] que = rx.get(l).split("@");
							String r1 = que[0];
							String r2 = que[1];
							String r3 = que[2];
							String path = "src/resources/"+ r1 + "@" + r2 + "@" + r3+ ".ser";
							x6 = getObj1(path, you);
							Object y6 = null;
							y6 = getObj2(path, you);
							Object z6 = null;
							z6 = getObj3(path , you);
							removefromOctree(path, getfilepath(strTableName, pagenum), you.get(clusteringkeyname), x6, y6, z6);

						}	
						if (p.numOfRecords == 0) {
							t.pages.remove(pagenum);
							t.numberofpages--;
							File f6 = new File("src/resources/" + strTableName + pagenum + ".ser");
							f6.delete();
							updatetableondisk(strTableName, t);
						} else {
							p.max = p.records.get(p.numOfRecords - 1).get(clusteringkeyname);
							p.min = p.records.get(0).get(clusteringkeyname);
							updatepageondisk(strTableName, pagenum + 1, p);
							updatetableondisk(strTableName, t);
						}

					} else
						throw new DBAppException("record not found");
				} else {

					ArrayList<Integer> arr = new ArrayList<Integer>();
					ArrayList<Integer> arr2 = new ArrayList<Integer>();
					ArrayList<Hashtable> arr3 = new ArrayList<Hashtable>();
					ArrayList<String> arr4 = new ArrayList<String>();
					for (int i = 0; i < t.numberofpages; i++) {
						arr.clear();
						arr3.clear();
						page change;
						change = getwantedpage(strTableName, i);
						for (int j = 0; j < change.numOfRecords; j++) {
							int htbl = 0;
							Hashtable<String, Object> rh = change.records.get(j);
							for (Object s : htblColNameValue.keySet()) {
								String item = s.toString();
								if (rh.containsKey(item) ) {
									if (compare2objects(rh.get(item), htblColNameValue.get(item)) == 0) {
										htbl++;
									}
								}
							}
							if (htbl == htblColNameValue.size()) {
								arr.add(j);
							}
						}
						for (int z = 0; z < arr.size(); z++) {
							int x = arr.get(z);
							arr3.add(change.records.get(x));
						}
						for (int bj = 0; bj < arr3.size(); bj++) {
							change.records.remove(arr3.get(bj));
							change.numOfRecords--;
							t.count--;
							ArrayList<String> rq = getindexnames(strTableName) ; 
							for (int l = 0; l < rq.size(); l++) {
								Object x = null;
								String[] que = rq.get(l).split("@");
								String r1 = que[0];
								String r2 = que[1];
								String r3 = que[2];
								String path25 = "src/resources/"+ r1 + "@" + r2 + "@" + r3 + ".ser";
								x = getObj1(path25, arr3.get(bj));
								Object y = null;
								y = getObj2(path25, arr3.get(bj));
								Object z = null;
								z = getObj3(path25, arr3.get(bj));

								removefromOctree(path25, getfilepath(strTableName, i), arr3.get(bj).get(clusteringkeyname), x, y,
										z);
							}

							if (change.numOfRecords > 0) {
								change.max = change.records.get(change.numOfRecords - 1).get(clusteringkeyname);
								change.min = change.records.get(0).get(clusteringkeyname);
							}
							t.pages.remove(i);
							t.pages.add(i, getfilepath(strTableName, i));
							updatepageondisk(strTableName, i + 1, change);
							updatetableondisk(strTableName, t);

						}

						if (change.numOfRecords == 0) {
							arr2.add(i);
						}
					}
					for (int q = 0; q < arr2.size(); q++) {
						int s = arr2.get(q);
						int soso = s + 1;
						File f = new File("src/resources/" + strTableName + soso + ".ser");
						f.delete();
						arr4.add(t.pages.get(s));
					}
					for (int qj = 0; qj < arr4.size(); qj++) {
						t.pages.remove(arr4.get(qj));
						updatetableondisk(strTableName, t);
					}
					t.numberofpages -= arr2.size();
					updatetableondisk(strTableName, t);
				}
			} }
		catch (Exception e) {
			e.printStackTrace();
			throw new DBAppException(e.getMessage()) ; 
		}
	}

	private int getpagenum(String strTableName, String r1) throws Exception {
		FileInputStream fileIn = new FileInputStream("src/resources/" + strTableName + ".ser");
		ObjectInputStream in = new ObjectInputStream(fileIn);
		table p = (table) in.readObject();
		fileIn.close();
		in.close();
		for (int i = 0; i < p.numberofpages; i++) {
			if (p.pages.get(i).equals(r1)) {
				return i;
			}
		}
		return -1;
	}

	public Iterator selectFromTable(SQLTerm[] arrSQLTerms, String[] strarrOperators) throws DBAppException {
		Vector <Hashtable<String,Object>> res = new Vector <Hashtable<String,Object>> () ; 
		try {
			String strTableName = arrSQLTerms[0].get_strTableName() ;
			if (arrSQLTerms.length - 1 != strarrOperators.length)
				throw new DBAppException("Number of terms and operators does not match.");
			validateOperators(strarrOperators);
			BufferedReader br;
			br = new BufferedReader(new FileReader("src/resources/metadata.csv"));
			String curLine;
			curLine = br.readLine();
			String clusteringkeyname = "";
			boolean b = false;
			while (curLine != null) {
				String[] metaData = curLine.split(",");
				if (metaData[0].equals(strTableName)) {
					b = true;
					if (metaData[3].equals("True")) {
						clusteringkeyname = metaData[1];
					}
				}
				curLine = br.readLine();
			}
			if (b == false) {
				throw new DBAppException("There is no such table in the database.");
			}
			FileInputStream fileIn;
			fileIn = new FileInputStream("src/resources/" + strTableName + ".ser");
			ObjectInputStream in;
			in = new ObjectInputStream(fileIn);
			table t;
			t = (table) in.readObject();
			in.close();
			fileIn.close();	  
			validateTerms(arrSQLTerms);

			ArrayList <String> indexnames = getindexnames(strTableName)  ; 
			Vector <Vector<String>> colnames = new Vector <Vector<String>> () ; 

			String r1 = "" ;
			String r2 = "" ; 
			String r3 = "" ; 
			boolean flag = false; 

			for (int i = 0 ; i< indexnames.size() ; i ++) {
				String[] que = (indexnames.get(i)).split("@");
				r1 = que[0];
				r2 = que[1];
				r3 = que[2];
				Vector  <String> v1 = new Vector <String> () ;
				v1.add(r1) ; v1.add(r2) ; v1.add(r3) ; 
				colnames.add(v1) ; 
			}

			for (int i = 0 ; i <arrSQLTerms.length ; i ++) {

				if (i<=arrSQLTerms.length-3) { 
					for (int j = 0 ; j<colnames.size() ; j++) {
						if(colnames.get(j).contains(arrSQLTerms[i].get_strColumnName()) && colnames.get(j).contains(arrSQLTerms[i+1].get_strColumnName()) && colnames.get(j).contains(arrSQLTerms[i+2].get_strColumnName())) {
							flag = true ;
							break ;
						}
					}
				}
				if (flag) {

					//use octree and increment i
					if (i==0) {

						res.addAll(OctreeSearch(arrSQLTerms[i],arrSQLTerms[i+1],arrSQLTerms[i+2],clusteringkeyname)) ; 
					}
					else 
						res= starrOperatorAction(res,OctreeSearch(arrSQLTerms[i],arrSQLTerms[i+1],arrSQLTerms[i+2],clusteringkeyname),strarrOperators[i-1],clusteringkeyname) ; 
					i+=3 ;



				}
				else { //linear search
					if (i==0) {
						res.addAll(LinearSearch(t,arrSQLTerms[i])) ; 
					}
					else 
						res= starrOperatorAction(res,LinearSearch(t,arrSQLTerms[i]),strarrOperators[i-1],clusteringkeyname) ; 
				}
			}
			res = removeDuplicates(res,clusteringkeyname) ; 
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new DBAppException(e.getMessage()) ; 
		}
		return res.iterator();
	}


	private Vector <Hashtable<String, Object>> OctreeSearch(SQLTerm sqlTerm, SQLTerm sqlTerm2,
			SQLTerm sqlTerm3, String clusteringkeyname) throws Exception {
		Vector <Hashtable <String,Object>> result = new Vector <Hashtable<String,Object>> (); 
		FileInputStream fileIn;
		fileIn = new FileInputStream("src/resources/" + sqlTerm.get_strColumnName() + "@"+ sqlTerm2.get_strColumnName() + "@"  + sqlTerm3.get_strColumnName() + ".ser");
		ObjectInputStream in;
		in = new ObjectInputStream(fileIn);
		Octree t = (Octree) in.readObject();
		in.close();
		fileIn.close();	  
		Object x = sqlTerm.get_objValue() ; 
		Object y = sqlTerm2.get_objValue() ; 
		Object z = sqlTerm3.get_objValue() ; 
		String [] operators = new String[3] ;
		operators[0] = sqlTerm.get_strOperator() ; 
		operators[1] = sqlTerm2.get_strOperator() ; 
		operators[2] = sqlTerm3.get_strOperator() ;  
		Hashtable <String,Object> res = t.search(x, y, z, operators) ; 

		for (String item : res.keySet())  {

			Object r2 = res.get(item) ; 
			if (r2 instanceof java.lang.Integer) {
				int sho = (Integer)(r2) ; 
				FileInputStream fileIn2;
				fileIn2 = new FileInputStream(item);
				ObjectInputStream in2;
				in2 = new ObjectInputStream(fileIn2);
				page p;
				p = (page) in2.readObject();
				in2.close();
				fileIn2.close();	  
				Hashtable  <String,Object> you = new Hashtable <String,Object> () ; 
				you.put(clusteringkeyname, sho) ; 
				int recnum = BinarySearch3(p.records,you,clusteringkeyname) ;
				result.add(p.records.get(recnum)) ; 
			} else if (r2 instanceof java.lang.Double) {
				Double sho = (Double)(r2) ; 
				FileInputStream fileIn2;
				fileIn2 = new FileInputStream(item);
				ObjectInputStream in2;
				in2 = new ObjectInputStream(fileIn2);
				page p;
				p = (page) in2.readObject();
				in2.close();
				fileIn2.close();	  
				Hashtable  <String,Object> you = new Hashtable <String,Object> () ; 
				you.put(clusteringkeyname, sho) ; 
				int recnum = BinarySearch3 (p.records,you,clusteringkeyname) ; 
				result.add(p.records.get(recnum)) ; 
			} else if (r2 instanceof java.lang.String) {
				FileInputStream fileIn2;
				fileIn2 = new FileInputStream(item);
				ObjectInputStream in2;
				in2 = new ObjectInputStream(fileIn2);
				page p;
				p = (page) in2.readObject();
				in2.close();
				fileIn2.close();	  
				Hashtable  <String,Object> you = new Hashtable <String,Object> () ; 
				you.put(clusteringkeyname, r2.toString()) ; 
				int recnum = BinarySearch3 (p.records,you,clusteringkeyname) ; 
				result.add(p.records.get(recnum)) ; 

			} else {
				Date sho = new SimpleDateFormat("yyyy-MM-dd").parse(r2.toString()) ; 
				FileInputStream fileIn2;
				fileIn2 = new FileInputStream(item);
				ObjectInputStream in2;
				in2 = new ObjectInputStream(fileIn2);
				page p;
				p = (page) in2.readObject();
				in2.close();
				fileIn2.close();	  
				Hashtable  <String,Object> you = new Hashtable <String,Object> () ; 
				you.put(clusteringkeyname, sho) ; 
				int recnum = BinarySearch3 (p.records,you,clusteringkeyname) ; 
				result.add(p.records.get(recnum)) ; 
			}
		}

		return result;
	}

	private void validateTerms(SQLTerm[] arrSQLTerms) throws DBAppException, Exception {
		String targetTableName = arrSQLTerms[0].get_strTableName();
		for (SQLTerm term : arrSQLTerms) {
			if (!term.get_strTableName().equals(targetTableName)) {
				throw new DBAppException("The table name must be the same for all terms.");
			}
		}

		FileReader metadata = new FileReader("src/resources/metadata.csv");
		BufferedReader br = new BufferedReader(metadata);
		String curLine;
		Hashtable<String, String> colDataTypes = new Hashtable<>();
		while ((curLine = br.readLine()) != null) {
			String[] res = curLine.split(",");
			if (res[0].equals(arrSQLTerms[0].get_strTableName())) {
				colDataTypes.put(res[1], res[2]);
			}
		}
		for (SQLTerm term : arrSQLTerms) {
			String columnName = term.get_strColumnName();
			Object columnValue = term.get_objValue();
			if (!colDataTypes.containsKey(columnName)) {
				throw new DBAppException("Column wanted does not exist in the table");
			}
			Class colClass = Class.forName(colDataTypes.get(columnName));
			if (!colClass.isInstance(columnValue)) {
				throw new DBAppException("Data types are incompatible");
			}
		}

	}
	private void validateOperators(String[] strarrOperators) throws DBAppException {
		// TODO Auto-generated method stub
		for (String operator : strarrOperators) {
			if (!(operator.equalsIgnoreCase("or") || operator.equalsIgnoreCase("and") || operator.equalsIgnoreCase("xor")))
				throw new DBAppException("The operator is incorrect");
		}
	}
	private static int BinarySearch(Vector<Hashtable<String, Object>> page, Hashtable<String, Object> O,
			String clusteringkey) {
		
		int lb = 0, ub = page.size() - 1;
		while (lb <= ub) {
			int m = (lb + ub) / 2;
			if (O.equals(page.get(m)))
				return m;
			if ((compare2objects(page.get(m).get(clusteringkey), O.get(clusteringkey))) > 0)
				lb = m + 1;
			else
				ub = m - 1;
		}
		return -1;
	}
	private static int BinarySearch3(Vector<Hashtable<String, Object>> page, Hashtable<String, Object> O,
			String clusteringkey) {
		int lb = 0, ub = page.size() - 1;
		while (lb <= ub) {
			int m = (lb + ub) / 2;
			 
			if ((compare2objects(page.get(m).get(clusteringkey), O.get(clusteringkey))) == 0)
				return m;
			if ((compare2objects(page.get(m).get(clusteringkey), O.get(clusteringkey))) < 0)
				lb = m + 1;

			else
				ub = m - 1;
		}

		return -1;
	}

	private static int pageBinarySearch(Vector<String> pages, Hashtable<String, Object> O, String clusteringkey,
			int pagecount) throws ClassNotFoundException, IOException {

		int lb = 0, ub = pagecount - 1;
		while (lb <= ub) {
			int m = (lb + ub) / 2;
			page p = getwantedpagebyfilepath(pages.get(m));

			if ((compare2objects(O.get(clusteringkey), p.min)) > 0
					&& (compare2objects(O.get(clusteringkey), p.max)) < 0)
				return m;
			if ((compare2objects(O.get(clusteringkey), p.max)) > 0 && p.numOfRecords < p.maxsize) {
				return m;
			}
			if ((compare2objects(O.get(clusteringkey), p.min)) < 0 && p.numOfRecords < p.maxsize) {
				return m;
			}
			if ((compare2objects(O.get(clusteringkey), p.max)) > 0)
				lb = m + 1;
			else
				ub = m - 1;
		}
		return pagecount - 1;
	}

	private static page getwantedpagebyfilepath(String string) throws IOException, ClassNotFoundException {
		FileInputStream fileIn = new FileInputStream(string);
		ObjectInputStream in = new ObjectInputStream(fileIn);
		page p = (page) in.readObject();
		fileIn.close();
		in.close();
		return p;
	}

	private static int compare2objects(Object obj1, Object obj2) {
		if (obj1 == null) {
			return -1;
		}
		if (obj2 == null) {
			return 1;
		}

		if (obj1 instanceof java.lang.Integer) {
			return ((Integer) obj1).compareTo((Integer) obj2);
		} else if (obj1 instanceof java.lang.Double) {
			return ((Double) obj1).compareTo((Double) obj2);
		} else if (obj1 instanceof java.lang.String) {
			return ((String) obj1).compareTo((String) obj2);

		} else {
			return ((Date) obj1).compareTo((Date) obj2);
		}
	}

	private static page getwantedpage(String strTableName, int pagenum) throws IOException, ClassNotFoundException {
		int x = pagenum + 1;
		FileInputStream fileIn = new FileInputStream("src/resources/" + strTableName + x + ".ser");
		ObjectInputStream in = new ObjectInputStream(fileIn);
		page p = (page) in.readObject();
		fileIn.close();
		in.close();
		return p;

	}

	private static String getfilepath(String strTableName, int pagenum) {
		int x = pagenum + 1;
		String s = "src/resources/" + strTableName + x + ".ser";
		return s;
	}

	private static void insertintoOctree(String indexfilepath, String pagefilepath, Object clusteringKey, Object x, Object y,
			Object z) throws Exception {
		FileInputStream fileIn = new FileInputStream(indexfilepath);
		ObjectInputStream in = new ObjectInputStream(fileIn);
		Octree t = (Octree) in.readObject();
		fileIn.close();
		in.close();
		t.insert(x, y, z, pagefilepath, clusteringKey);
		File f = new File(indexfilepath);
		f.delete();
		FileOutputStream fileOut;
		try {
			fileOut = new FileOutputStream(indexfilepath);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(t);
			out.close();
			fileOut.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void removefromOctree(String indexfilepath, String pagefilepath, Object clusteringKey, Object x, Object y,
			Object z) throws Exception {
		FileInputStream fileIn = new FileInputStream(indexfilepath);
		ObjectInputStream in = new ObjectInputStream(fileIn);
		Octree t = (Octree) in.readObject();
		fileIn.close();
		in.close();
		t.remove2(x, y, z, pagefilepath, clusteringKey);
		File f = new File(indexfilepath);
		f.delete();
		FileOutputStream fileOut;
		try {
			fileOut = new FileOutputStream(indexfilepath);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(t);
			out.close();
			fileOut.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static Object getObj1(String filepath, Hashtable<String, Object> htbl) throws Exception {
		FileInputStream fileIn = new FileInputStream(filepath);
		ObjectInputStream in = new ObjectInputStream(fileIn);
		Octree t = (Octree) in.readObject();
		fileIn.close();
		in.close();
		String s = t.getCol1();
		return htbl.get(s);
	}

	public static Object getObj2(String filepath, Hashtable<String, Object> htbl) throws Exception {
		FileInputStream fileIn = new FileInputStream(filepath);
		ObjectInputStream in = new ObjectInputStream(fileIn);
		Octree t = (Octree) in.readObject();
		fileIn.close();
		in.close();
		String s = t.getCol2();
		return htbl.get(s);
	}

	public static Object getObj3(String filepath, Hashtable<String, Object> htbl) throws Exception {
		FileInputStream fileIn = new FileInputStream(filepath);
		ObjectInputStream in = new ObjectInputStream(fileIn);
		Octree t = (Octree) in.readObject();
		fileIn.close();
		in.close();
		String s = t.getCol3();
		return htbl.get(s);
	}

	public ArrayList <String>  getindexcolnames (String strTableName , String x, String y ,String z) throws Exception {
		ArrayList<String> arr = new ArrayList <String> () ; 
		BufferedReader br;
		br = new BufferedReader(new FileReader("src/resources/metadata.csv"));
		String curLine;
		curLine = br.readLine();
		int count = 0 ; 
		while (curLine != null) {

			String[] res = curLine.split(",");
			if (!res[0].equals(strTableName)) {
				continue ; 
			}
			String indexname = res[3] ; 
			count = 0 ; 
			BufferedReader br2 = new BufferedReader(new FileReader("src/resources/metadata.csv"));
			String curLine2;
			curLine2 = br2.readLine();
			while (curLine2 != null) {
				String[] res2 = curLine2.split(",");
				String indexname2 = res2[3] ; 
				if (indexname!="null" && indexname2.equals(indexname) && ( res2[1].equals(x) ||res2[1].equals(y)||res2[1].equals(z)) ) {
					count ++ ; 	
				}
				if (count == 3) {
					arr.add(indexname) ; 
				}
				curLine2 = br2.readLine();
			}
			curLine = br.readLine();

		}
		return arr ; 
	}
	public ArrayList <String>  getindexnames (String strTableName) throws Exception {
		ArrayList<String> arr = new ArrayList <String> () ; 
		BufferedReader br;
		br = new BufferedReader(new FileReader("src/resources/metadata.csv"));
		String curLine;
		curLine = br.readLine();
		boolean b = true ; 
		while (curLine != null) {
			String[] res = curLine.split(",");
			if (!res[0].equals(strTableName)) {  
				b =false ; 
			}
			String indexname = res[4] ; 
			if (!(indexname.equals("null")) && !(arr.contains(indexname)) && b ) 
				arr.add(indexname) ; 
			curLine = br.readLine();
		}
		return arr ; 
	}

	public Vector <Hashtable <String,Object>> starrOperatorAction (Vector <Hashtable <String,Object>> v1, Vector <Hashtable <String,Object>> v2, String operator,Object clusteringkey) { 
		Vector <Hashtable <String,Object>> result = new Vector <Hashtable <String,Object>> () ; 
		if (operator.equalsIgnoreCase("or")) {
			for (int i = 0 ; i < v1.size() ; i ++) {
				if (v2.contains(v1.get(i))) ; 
				v1.remove(i) ; 
			}
			result.addAll(v1); 
			result.addAll(v2); 
		}
		else if (operator.equalsIgnoreCase("and")) {
			for (int i = 0 ; i<v1.size() ; i ++) {
				Hashtable <String,Object> x = v1.get(i) ; 
				if (v2.contains(x)) {
					result.add(x) ; 
				}
			}
		}
		else {
			for (int i = 0 ; i<v1.size() ; i ++) {
				Hashtable <String,Object> x = v1.get(i) ; 
				if (!v2.contains(x)) {
					result.add(x) ; 
				}
			}
			for (int i = 0 ; i<v2.size() ; i ++) {
				Hashtable <String,Object> x = v2.get(i) ; 
				if (!v1.contains(x)) {
					result.add(x) ; 
				}
			}
		}
		return result; 
	}

	public Vector <Hashtable <String,Object>> LinearSearch (table t, SQLTerm term) throws Exception { 
		Vector <Hashtable<String,Object>> res = new  Vector <Hashtable <String,Object>>() ; 
		for (int i =0 ; i < t.numberofpages ; i++) {
			FileInputStream fileIn = new FileInputStream(t.pages.get(i));
			ObjectInputStream in = new ObjectInputStream(fileIn);
			page p = (page) in.readObject();
			fileIn.close();
			in.close(); 
			for (int j = 0 ; j<p.numOfRecords ;j++ ) {
				if (term.get_strOperator().equals("=")) {
					if (p.records.get(j).get(term.get_strColumnName()).equals(term.get_objValue())) {
						res.add(p.records.get(j)) ; 
					}}
				else if (term.get_strOperator().equals(">")) {
					if (compare2objects(p.records.get(j).get(term.get_strColumnName()),term.get_objValue())>0) {
						res.add(p.records.get(j)) ; 
					}}
				else if (term.get_strOperator().equals("<")) {
					if (compare2objects(p.records.get(j).get(term.get_strColumnName()),term.get_objValue())<0) {
						res.add(p.records.get(j)) ; 
					}}
				else if (term.get_strOperator().equals(">=")) {
					if (compare2objects(p.records.get(j).get(term.get_strColumnName()),term.get_objValue())>=0) {
						res.add(p.records.get(j)) ; 
					}}
				else if (term.get_strOperator().equals("<=")) {
					if (compare2objects(p.records.get(j).get(term.get_strColumnName()),term.get_objValue())<=0) {
						res.add(p.records.get(j)) ; 
					}}
				else {
					if (compare2objects(p.records.get(j).get(term.get_strColumnName()),term.get_objValue())!=0) {
						res.add(p.records.get(j)) ; 
					}}
			}


		} 
		return res;
	}

	public static void updateMetadata2(String[] columns, String tableName) throws IOException {
		String[] output = new String[6];
		// try {
		String file = "src/resources/metadata.csv";
		FileReader reader = new FileReader(file);
		BufferedReader buff = new BufferedReader(reader);
		StringBuilder s = new StringBuilder();
		String line = buff.readLine();
		String indexName = columns[0] + "@" + columns[1] + "@" + columns[2];
		String indexType = "Octree";
		FileWriter finalOne = new FileWriter("src/resources/metadata.csv");
		do {
			boolean inserted = false;
			String arr[] = line.split(",");
			for (int i = 0; i < columns.length; i++) {
				if (columns[i].equals(arr[1]) && arr[0].equals(tableName)) {
					s.append(arr[0]).append(",");
					s.append(arr[1]).append(",");
					s.append(arr[2]).append(",");
					s.append(arr[3]).append(",");
					s.append(indexName).append(",");
					s.append(indexType).append(",");
					s.append(arr[6]).append(",");
					s.append(arr[7]).append('\n');
					inserted = true;
					break;
				}
			}
			if (!inserted) {
				s.append(line).append('\n');
			}
		} while ((line = buff.readLine()) != null);
		finalOne.write(s.toString());
		finalOne.close();
		return;

	}
	public Vector <Hashtable<String,Object>> removeDuplicates (Vector <Hashtable<String,Object>> htbl,String clusteringKey) {
	Vector <Hashtable<String,Object>> res = new Vector <Hashtable<String,Object>> (); 
	for (int i = 0 ; i<htbl.size() ; i++) {
		Hashtable<String,Object> x = htbl.get(i) ; 
		boolean b = true ; 
		for (int j = 0 ; j<htbl.size(); j++ ) {
			if (i!=j) {
			if (compare2objects(x.get(clusteringKey),htbl.get(j).get(clusteringKey))==0) {
				b = false ; 
				break; 
			}
		}
			}
		if (b) {
			res.add(x) ; 
			}
	}
	return res;
}
}


