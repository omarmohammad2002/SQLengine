public class DBAppException extends Exception {

	public DBAppException(String string) {
		super(string); 
	}

	public DBAppException() {
		// TODO Auto-generated constructor stub
		super(); 
	}

}
