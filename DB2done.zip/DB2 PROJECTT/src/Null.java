import java.io.Serializable;

public class Null implements Serializable {
public String toString() {
	return null ; 
}
}
