import java.io.IOException;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Vector;
public class page implements Serializable {
	Vector <Hashtable<String,Object>> records ;
	Object min;
	Object max;
	int numOfRecords;
	int maxsize ; 
	public page () throws IOException {
		this.records = new Vector <Hashtable<String,Object>> () ; 
		numOfRecords = 0 ;
	}
}
